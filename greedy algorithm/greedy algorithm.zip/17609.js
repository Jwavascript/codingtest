let fs = require('fs');
let input = fs.readFileSync('example.txt').toString().split('\n');

let t = Number(input[0]);
let pali = [];
for(let i = 1; i<=7; i++){
  pali.push(input[i].);
}
console.log(pali);
